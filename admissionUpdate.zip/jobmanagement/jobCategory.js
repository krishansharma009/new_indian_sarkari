const { DataTypes, Model } = require("sequelize");
const sequelize = require("../../config/datasource-db");

class JobCategory extends Model {}

JobCategory.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    job_id: {
      type: DataTypes.INTEGER,
      references: {
        model: "Job",
        key: "id",
      },
    },
    category_id: {
      type: DataTypes.INTEGER,
      references: {
        model: "Category",
        key: "id",
      },
    },
  },
  {
    sequelize,
    modelName: "JobCategory",
    tableName: "job_categories",
    timestamps: true,
    paranoid: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
  }
);

// Define associations
JobCategory.belongsTo(Job, { foreignKey: "job_id", onDelete: "CASCADE" });
JobCategory.belongsTo(Category, {
  foreignKey: "category_id",
  onDelete: "CASCADE",
});

module.exports = JobCategory;
